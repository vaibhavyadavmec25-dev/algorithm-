# Flexible Job-Shop Scheduling (FJSP) — Algo Prepathon

This repository implements the complete pipeline requested in the provided
assignment:

**Generate → Validate → Solve → Stress Test → Analyze → Improve**

The assignment defines an FJSP instance as jobs made of ordered operations,
where each operation has a non-empty eligible-machine set and a positive
machine-dependent processing time. The schedule must respect machine
eligibility, exact duration, job precedence, machine non-overlap,
non-preemption, non-negative time, and completeness.

## Repository structure

```text
fjsp/
├── generator.py       # structured random FJSP generator
├── validator.py       # independent schedule checker/evaluator
├── algorithm.py       # constructive priority-dispatching scheduler
├── metrics.py         # makespan/utilization metrics
├── experiment.py      # multi-class, multi-seed experiments
├── edge_cases.py      # required hand-built stress cases
├── model.py
└── cli.py

tests/
└── test_pipeline.py

instances/
results/
analysis/
experiments/
```

## 1. Generator design

The generator does not simply write uniform random values.

### Machine eligibility

For each operation, the target flexibility is a number in `[0,1]`.
A bounded Gaussian perturbation is applied and converted into an integer
eligible-machine count between 1 and `M`. For bottleneck-heavy classes,
designated bottleneck machines receive higher sampling weights.

### Processing times

A log-normal distribution creates positive, right-skewed processing times.
Its spread (`sigma`) is the variance-control parameter. Each machine receives
a latent speed factor, and one eligible machine receives a deliberate
specialist advantage. Bottleneck machines are intentionally attractive,
creating contention.

### Instance classes

| Class | Flexibility | Sigma | Bottleneck probability | Time range |
|---|---:|---:|---:|---:|
| average | .55 | .35 | .15 | 5–60 |
| easy | .35 | .18 | .05 | 5–40 |
| hard | .80 | .60 | .25 | 5–100 |
| low-flexibility | .15 | .30 | .10 | 5–60 |
| high-flexibility | .92 | .45 | .15 | 5–70 |
| bottleneck-heavy | .70 | .40 | .75 | 5–80 |
| unbalanced | .60 | .70 | .35 | 2–250 |
| high-variance | .60 | 1.00 | .20 | 1–500 |
| extreme | .95 | .95 | .45 | 1–500 |

Every operation is constructed with at least one eligible machine and a
positive processing time for every eligible machine, so malformed instances
are not emitted by construction. The seed and all generation parameters are
stored in the instance metadata.

## 2. Validator

The validator is independent of the scheduler. It checks:

- exact job/operation completeness;
- duplicate operations;
- unknown IDs;
- machine eligibility;
- numeric and non-negative start times;
- exact completion time;
- job precedence;
- machine overlap;
- and returns reconstructed machine schedules, job completion times,
  and makespan.

It prints diagnostics rather than trusting the solver.

## 3. Scheduling algorithm

The implemented method is a constructive list scheduler.

1. Find operations whose predecessors are already scheduled.
2. Give priority to the operation with the largest remaining minimum
   processing work (a critical-chain proxy).
3. Break ties using lower routing flexibility.
4. For every eligible machine, compute the earliest non-overlapping start.
5. Select the machine with the earliest completion, then earliest start,
   then lower current busy load.
6. Commit the operation and repeat.

This is deterministic for a fixed instance. It is intentionally a strong
baseline rather than an unnecessarily complicated black-box optimizer.

### Search space

A schedule contains both routing decisions (which machine each operation
uses) and sequencing decisions (the order of operations on each machine).
The algorithm greedily commits both while respecting precedence.

### Complexity

With `N` operations and `M` machines, each operation considers at most `M`
machines and scans its machine's current intervals. A simple upper-bound
description is approximately `O(N*M*N)` in the worst case, while typical
instances are substantially faster because intervals are short.

## 4. Running

From the repository root:

```bash
python run_pipeline.py
```

Generate an individual instance:

```bash
python -m fjsp.generator --jobs 12 --machines 6 --ops 6 \
  --class bottleneck-heavy --seed 10 \
  --out instances/bottleneck10.json
```

Solve:

```bash
python -m fjsp.algorithm instances/bottleneck10.json \
  --out results/bottleneck10_schedule.json
```

Validate:

```bash
python -m fjsp.cli validate instances/bottleneck10.json results/bottleneck10_schedule.json
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

Run the complete experiment suite:

```bash
python -m fjsp.experiment
```

## 5. Failure analysis

The main structural failure modes to inspect are:

1. **High flexibility:** many routing choices enlarge the search space. A
   greedy assignment can consume a globally useful machine early.
2. **Bottleneck-heavy:** attractive processing times concentrate work on a
   small number of machines, so local processing-time decisions can increase
   global contention.
3. **High variance:** a single very long operation can dominate the critical
   path and make otherwise good local decisions irrelevant.
4. **Unbalanced instances:** heterogeneous machine speeds make the wrong
   routing choice expensive.
5. **Extreme cases:** simple dispatching has limited look-ahead and can miss
   a better global routing/sequence combination.

### Proposed improvements

These are deliberately listed as future improvements rather than claiming
that they were implemented:

- beam search over machine assignments;
- tabu search or simulated annealing over routing/sequence neighborhoods;
- critical-path-aware look-ahead;
- explicit lower bounds from job work and machine load;
- bottleneck-aware penalties in the assignment objective;
- repeated randomized construction with best-of-K selection;
- CP-SAT/MILP comparison for small instances.

## 6. Reproducibility

Every random instance stores:

- seed;
- generator class;
- jobs/machines/operations;
- flexibility;
- processing-time range;
- variance parameter;
- bottleneck probability;
- selected bottleneck machines.

The experiment suite uses five seeds per class and therefore does not base
its aggregate observations on one random instance.

## 7. Assignment coverage

The implementation covers Parts A–D, reproducibility, submission structure,
and the requested hand-built edge cases. The generated `results/summary.json`
and `results/experiment_results.csv` are the experiment artifacts.
