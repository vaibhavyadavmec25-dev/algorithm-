# Failure Analysis

## Observation 1 — Bottleneck-heavy instances

The generator deliberately makes selected machines both attractive and
frequently eligible. This creates a structural tension: the scheduler sees
a short processing time but the same machine may already have many operations.

## Evidence to collect

Use `results/experiment_results.csv` and compare:

- average makespan by class;
- machine utilization;
- runtime;
- feasibility across seeds.

A useful follow-up experiment is to vary bottleneck probability while keeping
jobs, machines, operations, and seed sets fixed.

## Hypothesis

Greedy earliest-completion assignment has only local information. It can
select a machine because it finishes the current operation early even when
that machine is strategically important for downstream operations.

## Structural explanation

FJSP has two coupled decisions:

1. route an operation to a machine;
2. sequence operations on each machine.

The decisions interact through precedence and contention. A local improvement
in one dimension can create a worse critical path later.

## Proposed improvement

Add a downstream congestion penalty:

`score = earliest_completion + alpha * predicted_future_load`

where predicted future load includes operations that have few alternative
machines.

---

## Observation 2 — High variance

Log-normal processing times produce occasional very long operations.

## Hypothesis

The longest operation can dominate the makespan, so the scheduler's local
tie-breaking becomes less important than avoiding a long operation on an
already critical machine.

## Proposed improvement

Use a critical-path lower bound and prioritize operations by
`remaining_work / routing_flexibility`, with additional look-ahead.

---

## Observation 3 — High flexibility

High flexibility increases routing choices.

## Hypothesis

More choices enlarge the decision space. A constructive method commits
without exploring enough alternatives, so a locally feasible assignment may
be globally inferior.

## Proposed improvement

Keep the best `K` partial schedules (beam search) or apply local search after
the initial schedule.

---

## Observation 4 — Low flexibility

Low flexibility reduces routing choices but increases the importance of
machine sequencing.

## Hypothesis

When operations have only one or two eligible machines, the main remaining
source of optimization is the order in which operations use those machines.

## Proposed improvement

Use a dispatching priority based on slack/remaining work and perform a
pairwise sequence-swap neighborhood on critical machines.

---

# Interpretation rule

Do not claim an algorithmic improvement from one random run. Use multiple
seeds and report aggregates. The experiment CSV is designed for that purpose.
