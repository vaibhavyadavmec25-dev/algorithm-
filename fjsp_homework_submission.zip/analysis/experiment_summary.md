# Experiment Summary

| Class | Feasible | Mean makespan | Std. dev. | Mean runtime (s) |
|---|---:|---:|---:|---:|
| average | 5/5 | 209.40 | 24.81 | 0.000914 |
| easy | 5/5 | 173.00 | 15.28 | 0.000869 |
| hard | 5/5 | 290.20 | 37.53 | 0.001115 |
| low-flexibility | 5/5 | 239.40 | 26.87 | 0.000772 |
| high-flexibility | 5/5 | 219.40 | 19.22 | 0.001109 |
| bottleneck-heavy | 5/5 | 154.60 | 9.91 | 0.001002 |
| unbalanced | 5/5 | 229.20 | 39.86 | 0.001118 |
| high-variance | 5/5 | 437.40 | 86.77 | 0.001018 |
| extreme | 5/5 | 498.00 | 51.38 | 0.004877 |

All aggregate values use five seeds per class.