from pathlib import Path
from fjsp.generator import generate_instance, save_instance
from fjsp.algorithm import solve, save_schedule
from fjsp.validator import validate_schedule
from fjsp.metrics import calculate_metrics
from fjsp.edge_cases import save_cases
from fjsp.experiment import run_suite

Path("instances").mkdir(exist_ok=True)
Path("results").mkdir(exist_ok=True)

inst = generate_instance(10, 5, 5, "average", seed=42)
save_instance(inst, "instances/demo.json")
schedule = solve(inst, seed=42)
save_schedule(schedule, "results/demo_schedule.json")
validation = validate_schedule(inst, schedule)
print("DEMO:", calculate_metrics(inst, validation))

save_cases()
rows, summary = run_suite()
print("\nEXPERIMENT SUMMARY")
for cls, data in summary.items():
    print(cls, data)
