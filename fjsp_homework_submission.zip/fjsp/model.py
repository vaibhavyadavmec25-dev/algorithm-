from dataclasses import dataclass, asdict
from typing import Dict, List, Any


@dataclass
class Operation:
    job_id: int
    operation_id: int
    eligible_machines: List[int]
    processing_times: Dict[int, int]


@dataclass
class Job:
    job_id: int
    operations: List[Operation]


def instance_to_dict(instance: Dict[str, Any]) -> Dict[str, Any]:
    return instance


def schedule_to_dict(schedule: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return schedule
