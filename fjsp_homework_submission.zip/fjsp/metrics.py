from __future__ import annotations
from typing import Dict, Any, List


def calculate_metrics(instance: Dict[str, Any], validation: Dict[str, Any]) -> Dict[str, Any]:
    if not validation["valid"]:
        return {"feasible": False, "makespan": None}

    makespan = validation["makespan"]
    machine_schedules = validation["machine_schedules"]
    total_ops = sum(len(j["operations"]) for j in instance["jobs"])
    total_work = sum(
        next(iter(op["processing_times"].values()))
        for j in instance["jobs"] for op in j["operations"]
    )

    utilization = {}
    for m in instance["machines"]:
        busy = sum(
            x["completion_time"] - x["start_time"]
            for x in machine_schedules.get(m, [])
        )
        utilization[m] = busy / makespan if makespan else 0.0

    return {
        "feasible": True,
        "makespan": makespan,
        "total_operations": total_ops,
        "total_processing_work_lower_proxy": total_work,
        "machine_utilization": utilization,
        "average_machine_utilization": (
            sum(utilization.values()) / len(utilization) if utilization else 0.0
        ),
    }
