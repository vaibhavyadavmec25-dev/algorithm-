"""A constructive FJSP scheduler using priority dispatching + insertion."""

from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _remaining_work(job, op_index, current_instance) -> int:
    total = 0
    for op in job["operations"][op_index:]:
        total += min(op["processing_times"].values())
    return total


def _earliest_gap(intervals: List[Tuple[int, int]], ready: int, duration: int) -> int:
    """Find the earliest non-overlapping start at/after ready."""
    t = ready
    for s, c in sorted(intervals):
        if t + duration <= s:
            return t
        if t < c:
            t = c
    return t


def solve(instance: Dict[str, Any], seed: int = 1) -> List[Dict[str, Any]]:
    # The state contains only already-scheduled operations. At each iteration,
    # among currently ready operations we prioritize larger remaining work
    # (critical-chain proxy), then fewer routing choices, then job id.
    jobs = {j["job_id"]: j for j in instance["jobs"]}
    next_index = {j["job_id"]: 0 for j in instance["jobs"]}
    job_ready = {j["job_id"]: 0 for j in instance["jobs"]}
    machine_intervals: Dict[int, List[Tuple[int, int]]] = {m: [] for m in instance["machines"]}
    schedule: List[Dict[str, Any]] = []

    total_ops = sum(len(j["operations"]) for j in instance["jobs"])

    while len(schedule) < total_ops:
        candidates = []
        for jid, job in jobs.items():
            idx = next_index[jid]
            if idx >= len(job["operations"]):
                continue
            op = job["operations"][idx]
            remaining = _remaining_work(job, idx, instance)
            flexibility = len(op["eligible_machines"])
            candidates.append((-remaining, flexibility, jid, op))

        if not candidates:
            raise RuntimeError("No ready operation exists; instance is unexpectedly infeasible.")

        candidates.sort(key=lambda x: (x[0], x[1], x[2]))
        _, _, jid, op = candidates[0]
        ready = job_ready[jid]

        best = None
        for m_str in op["eligible_machines"]:
            m = int(m_str)
            d = int(op["processing_times"][str(m)])
            start = _earliest_gap(machine_intervals[m], ready, d)
            completion = start + d

            # Primary objective: earliest completion. Secondary: earliest start.
            # Tertiary: prefer the machine with less current load.
            load = sum(c - s for s, c in machine_intervals[m])
            key = (completion, start, load, m)
            if best is None or key < best[0]:
                best = (key, m, d, start, completion)

        _, m, d, start, completion = best
        machine_intervals[m].append((start, completion))
        job_ready[jid] = completion
        next_index[jid] += 1
        schedule.append({
            "job_id": jid,
            "operation_id": op["operation_id"],
            "machine_id": m,
            "start_time": start,
            "completion_time": completion,
        })

    return schedule


def save_schedule(schedule, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(schedule, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("instance")
    ap.add_argument("--out", default="results/schedule.json")
    args = ap.parse_args()
    instance = json.loads(Path(args.instance).read_text(encoding="utf-8"))
    schedule = solve(instance)
    save_schedule(schedule, args.out)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
