"""Independent schedule validator and evaluator."""

from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _ops(instance):
    out = {}
    for job in instance["jobs"]:
        for op in job["operations"]:
            out[(job["job_id"], op["operation_id"])] = op
    return out


def validate_schedule(instance: Dict[str, Any], schedule: List[Dict[str, Any]]) -> Dict[str, Any]:
    errors: List[str] = []
    expected = _ops(instance)
    machines = set(instance["machines"])

    if not isinstance(schedule, list):
        return {"valid": False, "errors": ["Schedule must be a list."], "makespan": None}

    seen = set()
    normalized = []

    for idx, item in enumerate(schedule):
        required = {"job_id", "operation_id", "machine_id", "start_time", "completion_time"}
        if not isinstance(item, dict) or not required.issubset(item):
            errors.append(f"Malformed schedule record at index {idx}. Required: {sorted(required)}")
            continue
        key = (item["job_id"], item["operation_id"])
        if key not in expected:
            errors.append(f"Invalid job/operation ID: {key}")
            continue
        if key in seen:
            errors.append(f"Duplicate operation: Job {key[0]} Op {key[1]}")
            continue
        seen.add(key)
        op = expected[key]
        m = item["machine_id"]
        if m not in machines:
            errors.append(f"Invalid machine ID {m} for Job {key[0]} Op {key[1]}")
        elif m not in op["eligible_machines"]:
            errors.append(f"Ineligible machine {m} for Job {key[0]} Op {key[1]}")
        try:
            s = float(item["start_time"])
            c = float(item["completion_time"])
        except (TypeError, ValueError):
            errors.append(f"Non-numeric time for Job {key[0]} Op {key[1]}")
            continue
        if s < 0:
            errors.append(f"Negative start time for Job {key[0]} Op {key[1]}")
        expected_c = s + op["processing_times"][str(m)] if m in op["eligible_machines"] else None
        if expected_c is not None and abs(c - expected_c) > 1e-9:
            errors.append(
                f"Wrong completion time for Job {key[0]} Op {key[1]}: "
                f"expected {expected_c}, got {c}"
            )
        normalized.append((key, m, s, c))

    missing = sorted(set(expected) - seen)
    for j, k in missing:
        errors.append(f"Missing operation: Job {j} Op {k}")

    by_job: Dict[int, Dict[int, Tuple[float, float]]] = {}
    for (j, k), m, s, c in normalized:
        by_job.setdefault(j, {})[k] = (s, c)

    for job in instance["jobs"]:
        jid = job["job_id"]
        for prev, nxt in zip(job["operations"], job["operations"][1:]):
            a = by_job.get(jid, {}).get(prev["operation_id"])
            b = by_job.get(jid, {}).get(nxt["operation_id"])
            if a and b and b[0] + 1e-9 < a[1]:
                errors.append(
                    f"Precedence violation: Job {jid} Op {nxt['operation_id']} "
                    f"starts at {b[0]} before Op {prev['operation_id']} ends at {a[1]}"
                )

    by_machine: Dict[int, List[Tuple[float, float, Tuple[int, int]]]] = {}
    for key, m, s, c in normalized:
        by_machine.setdefault(m, []).append((s, c, key))
    machine_schedules = {}
    for m, items in by_machine.items():
        items.sort()
        machine_schedules[m] = [
            {"job_id": k[0], "operation_id": k[1], "start_time": s, "completion_time": c}
            for s, c, k in items
        ]
        for a, b in zip(items, items[1:]):
            if b[0] + 1e-9 < a[1]:
                errors.append(
                    f"Machine {m} contains overlapping operations: "
                    f"Job {a[2][0]} Op {a[2][1]} [{a[0]}, {a[1]}], "
                    f"Job {b[2][0]} Op {b[2][1]} [{b[0]}, {b[1]}]"
                )

    job_completion = {}
    for job in instance["jobs"]:
        jid = job["job_id"]
        last = job["operations"][-1]["operation_id"]
        if last in by_job.get(jid, {}):
            job_completion[jid] = by_job[jid][last][1]

    makespan = max(job_completion.values(), default=None)
    valid = not errors
    return {
        "valid": valid,
        "errors": errors,
        "machine_schedules": machine_schedules,
        "job_completion_times": job_completion,
        "makespan": makespan if valid else None,
    }


def load_and_validate(instance_path: str, schedule_path: str) -> Dict[str, Any]:
    instance = json.loads(Path(instance_path).read_text(encoding="utf-8"))
    schedule = json.loads(Path(schedule_path).read_text(encoding="utf-8"))
    return validate_schedule(instance, schedule)
