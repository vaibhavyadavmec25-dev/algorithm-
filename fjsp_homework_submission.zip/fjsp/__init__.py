"""Flexible Job-Shop Scheduling Prepathon solution."""

__version__ = "1.0.0"
