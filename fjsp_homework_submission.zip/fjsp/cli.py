from __future__ import annotations
import argparse
import json
from pathlib import Path

from .algorithm import solve, save_schedule
from .validator import validate_schedule
from .metrics import calculate_metrics


def main():
    ap = argparse.ArgumentParser(description="FJSP pipeline")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("solve")
    s.add_argument("instance")
    s.add_argument("--out", default="results/schedule.json")

    v = sub.add_parser("validate")
    v.add_argument("instance")
    v.add_argument("schedule")

    args = ap.parse_args()

    if args.cmd == "solve":
        instance = json.loads(Path(args.instance).read_text())
        schedule = solve(instance)
        save_schedule(schedule, args.out)
        result = validate_schedule(instance, schedule)
        print(json.dumps(calculate_metrics(instance, result), indent=2))
    elif args.cmd == "validate":
        instance = json.loads(Path(args.instance).read_text())
        schedule = json.loads(Path(args.schedule).read_text())
        result = validate_schedule(instance, schedule)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
