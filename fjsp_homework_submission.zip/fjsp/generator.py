"""
Random FJSP instance generator.

The generator deliberately uses structured randomness rather than writing
independent uniform random numbers:
- operation flexibility is sampled around a target using a bounded Gaussian;
- processing times use a log-normal distribution, then receive machine-specific
  speed factors;
- bottleneck machines are given higher eligibility probability and attractive
  processing times, creating contention;
- machine-specialist advantages create useful routing asymmetry.
"""

from __future__ import annotations
import argparse
import json
import math
import random
from pathlib import Path
from typing import Any, Dict, Tuple


CLASS_PRESETS = {
    "average": dict(flexibility=0.55, sigma=0.35, bottleneck_probability=0.15,
                    advantage=0.85, time_range=(5, 60)),
    "easy": dict(flexibility=0.35, sigma=0.18, bottleneck_probability=0.05,
                 advantage=0.95, time_range=(5, 40)),
    "hard": dict(flexibility=0.80, sigma=0.60, bottleneck_probability=0.25,
                 advantage=0.70, time_range=(5, 100)),
    "extreme": dict(flexibility=0.95, sigma=0.95, bottleneck_probability=0.45,
                    advantage=0.55, time_range=(1, 500)),
    "bottleneck-heavy": dict(flexibility=0.70, sigma=0.40, bottleneck_probability=0.75,
                             advantage=0.55, time_range=(5, 80)),
    "high-flexibility": dict(flexibility=0.92, sigma=0.45, bottleneck_probability=0.15,
                             advantage=0.75, time_range=(5, 70)),
    "low-flexibility": dict(flexibility=0.15, sigma=0.30, bottleneck_probability=0.10,
                            advantage=0.90, time_range=(5, 60)),
    "unbalanced": dict(flexibility=0.60, sigma=0.70, bottleneck_probability=0.35,
                       advantage=0.50, time_range=(2, 250)),
    "high-variance": dict(flexibility=0.60, sigma=1.00, bottleneck_probability=0.20,
                          advantage=0.75, time_range=(1, 500)),
}


def _bounded_normal(rng: random.Random, mean: float, sd: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, rng.gauss(mean, sd)))


def _operation_count(value: int | Tuple[int, int], rng: random.Random) -> int:
    if isinstance(value, int):
        return value
    lo, hi = value
    return rng.randint(lo, hi)


def _eligible_count(machines: int, target_flexibility: float, rng: random.Random) -> int:
    if machines == 1:
        return 1
    noisy = _bounded_normal(rng, target_flexibility, 0.10, 0.0, 1.0)
    count = int(round(1 + noisy * (machines - 1)))
    return max(1, min(machines, count))


def generate_instance(
    number_of_jobs: int,
    number_of_machines: int,
    operations_per_job: int | Tuple[int, int],
    instance_class: str = "average",
    seed: int = 1,
    machine_flexibility: float | None = None,
    processing_time_range: Tuple[int, int] | None = None,
    processing_time_variance: float | None = None,
    bottleneck_probability: float | None = None,
) -> Dict[str, Any]:
    if number_of_jobs < 1 or number_of_machines < 1:
        raise ValueError("number_of_jobs and number_of_machines must be >= 1")

    rng = random.Random(seed)
    preset = CLASS_PRESETS.get(instance_class, CLASS_PRESETS["average"]).copy()
    flexibility = preset["flexibility"] if machine_flexibility is None else machine_flexibility
    sigma = preset["sigma"] if processing_time_variance is None else processing_time_variance
    bottleneck_prob = (
        preset["bottleneck_probability"]
        if bottleneck_probability is None else bottleneck_probability
    )
    tlo, thi = preset["time_range"] if processing_time_range is None else processing_time_range
    if not (0 <= flexibility <= 1):
        raise ValueError("machine_flexibility must be in [0, 1]")
    if sigma < 0:
        raise ValueError("processing_time_variance/sigma must be >= 0")
    if not (0 <= bottleneck_prob <= 1):
        raise ValueError("bottleneck_probability must be in [0, 1]")
    if tlo < 1 or thi < tlo:
        raise ValueError("processing_time_range must be positive and ordered")

    machines = list(range(1, number_of_machines + 1))
    bottleneck_count = max(1, int(round(number_of_machines * max(bottleneck_prob, 0.05)))) \
        if number_of_machines > 1 else 1
    bottleneck_machines = rng.sample(machines, bottleneck_count)

    # A latent machine-speed factor gives specialization without making any
    # machine unusable. Lower factor means faster processing.
    machine_speed = {
        m: math.exp(rng.gauss(0.0, 0.20 if instance_class != "unbalanced" else 0.45))
        for m in machines
    }

    jobs = []
    for j in range(1, number_of_jobs + 1):
        k = _operation_count(operations_per_job, rng)
        operations = []
        for op_id in range(1, k + 1):
            count = _eligible_count(number_of_machines, flexibility, rng)

            # Bottleneck-heavy classes make bottleneck machines more likely to
            # appear in eligible sets. We always preserve at least one machine.
            weights = []
            for m in machines:
                w = 1.0
                if m in bottleneck_machines:
                    w *= (1.0 + 5.0 * bottleneck_prob)
                weights.append(w)

            chosen = set()
            while len(chosen) < count:
                chosen.add(rng.choices(machines, weights=weights, k=1)[0])

            eligible = sorted(chosen)

            # Base time is log-normal: this naturally creates a long tail.
            geometric_mean = math.sqrt(tlo * thi)
            raw = rng.lognormvariate(math.log(geometric_mean), max(0.001, sigma))
            base = int(round(max(tlo, min(thi, raw))))

            # One eligible machine gets a deliberate advantage. This creates
            # a real assignment decision rather than identical alternatives.
            preferred = rng.choice(eligible)
            advantage = preset["advantage"]
            p = {}
            for m in eligible:
                factor = machine_speed[m]
                if m == preferred:
                    factor *= advantage
                if m in bottleneck_machines:
                    # Attractive but congested bottlenecks.
                    factor *= max(0.60, 1.05 - 0.45 * bottleneck_prob)
                val = int(round(base * factor))
                p[m] = max(1, min(thi, val))

            operations.append({
                "job_id": j,
                "operation_id": op_id,
                "eligible_machines": eligible,
                "processing_times": {str(m): p[m] for m in eligible},
            })
        jobs.append({"job_id": j, "operations": operations})

    return {
        "metadata": {
            "format_version": 1,
            "seed": seed,
            "instance_class": instance_class,
            "number_of_jobs": number_of_jobs,
            "number_of_machines": number_of_machines,
            "operations_per_job": operations_per_job,
            "machine_flexibility": flexibility,
            "processing_time_range": [tlo, thi],
            "processing_time_variance": sigma,
            "bottleneck_probability": bottleneck_prob,
            "bottleneck_machines": bottleneck_machines,
        },
        "machines": machines,
        "jobs": jobs,
    }


def save_instance(instance: Dict[str, Any], path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(instance, indent=2), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=10)
    ap.add_argument("--machines", type=int, default=5)
    ap.add_argument("--ops", type=int, default=5)
    ap.add_argument("--class", dest="instance_class", default="average", choices=sorted(CLASS_PRESETS))
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="instances/example.json")
    args = ap.parse_args()
    inst = generate_instance(args.jobs, args.machines, args.ops, args.instance_class, args.seed)
    save_instance(inst, args.out)
    print(f"Generated {args.out}")


if __name__ == "__main__":
    main()
