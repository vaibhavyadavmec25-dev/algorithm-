"""Experiment runner for multiple classes, seeds, and edge cases."""

from __future__ import annotations
import csv
import json
import time
from pathlib import Path
from statistics import mean, stdev

from .generator import generate_instance, save_instance
from .algorithm import solve, save_schedule
from .validator import validate_schedule
from .metrics import calculate_metrics


CLASSES = [
    "average", "easy", "hard", "low-flexibility", "high-flexibility",
    "bottleneck-heavy", "unbalanced", "high-variance", "extreme"
]


def run_suite(out_dir="results", instance_dir="instances", seeds=(1, 2, 3, 4, 5)):
    out_dir = Path(out_dir)
    instance_dir = Path(instance_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    instance_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for cls in CLASSES:
        for seed in seeds:
            # Moderate base size keeps the reference experiment quick.
            jobs, machines, ops = 12, 6, 6
            if cls == "extreme":
                jobs, machines, ops = 20, 8, 8
            inst = generate_instance(jobs, machines, ops, cls, seed)
            ip = instance_dir / f"{cls}_seed{seed}.json"
            save_instance(inst, ip)

            t0 = time.perf_counter()
            schedule = solve(inst, seed=seed)
            runtime = time.perf_counter() - t0
            validation = validate_schedule(inst, schedule)
            metrics = calculate_metrics(inst, validation)

            rows.append({
                "class": cls,
                "seed": seed,
                "jobs": jobs,
                "machines": machines,
                "operations": sum(len(j["operations"]) for j in inst["jobs"]),
                "feasible": metrics["feasible"],
                "makespan": metrics["makespan"],
                "runtime_sec": runtime,
                "avg_machine_utilization": metrics.get("average_machine_utilization"),
            })

    csv_path = out_dir / "experiment_results.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)

    summary = {}
    for cls in CLASSES:
        subset = [r for r in rows if r["class"] == cls]
        ms = [r["makespan"] for r in subset if r["makespan"] is not None]
        rt = [r["runtime_sec"] for r in subset]
        summary[cls] = {
            "runs": len(subset),
            "feasible_runs": sum(bool(r["feasible"]) for r in subset),
            "mean_makespan": mean(ms) if ms else None,
            "stdev_makespan": stdev(ms) if len(ms) > 1 else 0.0,
            "mean_runtime_sec": mean(rt),
        }

    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return rows, summary


if __name__ == "__main__":
    rows, summary = run_suite()
    for k, v in summary.items():
        print(k, v)
