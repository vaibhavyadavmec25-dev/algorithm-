"""Hand-built edge cases required by the brief."""

from __future__ import annotations
import json
from pathlib import Path


def op(j, k, machines):
    return {
        "job_id": j,
        "operation_id": k,
        "eligible_machines": sorted(machines),
        "processing_times": {str(m): int(p) for m, p in machines.items()},
    }


def make_cases():
    return {
        "single_machine": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1],
            "jobs": [
                {"job_id": 1, "operations": [op(1, 1, {1: 3}), op(1, 2, {1: 2})]},
                {"job_id": 2, "operations": [op(2, 1, {1: 4})]},
            ],
        },
        "one_job": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2, 3],
            "jobs": [{
                "job_id": 1,
                "operations": [
                    op(1, 1, {1: 5, 2: 2}),
                    op(1, 2, {2: 3, 3: 4}),
                    op(1, 3, {1: 2, 3: 8}),
                ],
            }],
        },
        "bottleneck": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2],
            "jobs": [
                {"job_id": 1, "operations": [op(1, 1, {1: 1, 2: 100}), op(1, 2, {1: 1})]},
                {"job_id": 2, "operations": [op(2, 1, {1: 1, 2: 100}), op(2, 2, {1: 1})]},
                {"job_id": 3, "operations": [op(3, 1, {1: 1, 2: 100})]},
            ],
        },
        "extreme_time_gap": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2],
            "jobs": [
                {"job_id": 1, "operations": [op(1, 1, {1: 1, 2: 10000})]},
                {"job_id": 2, "operations": [op(2, 1, {1: 10000, 2: 1})]},
            ],
        },
        "machine_advantage": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2],
            "jobs": [
                {"job_id": 1, "operations": [op(1, 1, {1: 1, 2: 50}), op(1, 2, {1: 50, 2: 1})]},
                {"job_id": 2, "operations": [op(2, 1, {1: 1, 2: 50}), op(2, 2, {1: 50, 2: 1})]},
            ],
        },
        "near_total_flexibility": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2, 3, 4],
            "jobs": [
                {"job_id": j, "operations": [op(j, 1, {1: 5, 2: 6, 3: 7, 4: 8})]}
                for j in range(1, 9)
            ],
        },
        "near_zero_flexibility": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2, 3, 4],
            "jobs": [
                {"job_id": j, "operations": [op(j, 1, {((j-1)%4)+1: 5})]}
                for j in range(1, 9)
            ],
        },
        "identical_processing_times": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2, 3],
            "jobs": [
                {"job_id": j, "operations": [op(j, 1, {1: 5, 2: 5, 3: 5})]}
                for j in range(1, 7)
            ],
        },
        "long_critical_chain": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2],
            "jobs": [
                {"job_id": 1, "operations": [
                    op(1, 1, {1: 4, 2: 4}), op(1, 2, {1: 4, 2: 4}),
                    op(1, 3, {1: 4, 2: 4}), op(1, 4, {1: 4, 2: 4}),
                    op(1, 5, {1: 4, 2: 4}),
                ]},
                {"job_id": 2, "operations": [op(2, 1, {1: 3, 2: 3})]},
            ],
        },
        "many_short_operations": {
            "metadata": {"seed": 0, "instance_class": "hand-built"},
            "machines": [1, 2, 3],
            "jobs": [
                {"job_id": j, "operations": [
                    op(j, 1, {1: 1, 2: 1, 3: 1}),
                    op(j, 2, {1: 1, 2: 1, 3: 1}),
                    op(j, 3, {1: 1, 2: 1, 3: 1}),
                    op(j, 4, {1: 1, 2: 1, 3: 1}),
                ]}
                for j in range(1, 11)
            ],
        },
    }


def save_cases(path="instances/edge_cases"):
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    cases = make_cases()
    for name, instance in cases.items():
        (p / f"{name}.json").write_text(json.dumps(instance, indent=2), encoding="utf-8")


if __name__ == "__main__":
    save_cases()
    print("Saved hand-built edge cases.")
