import copy
import unittest

from fjsp.generator import generate_instance
from fjsp.algorithm import solve
from fjsp.validator import validate_schedule


class TestPipeline(unittest.TestCase):
    def test_generated_instance_is_solvable_and_valid(self):
        for seed in range(1, 6):
            inst = generate_instance(8, 4, 5, "hard", seed)
            schedule = solve(inst, seed)
            result = validate_schedule(inst, schedule)
            self.assertTrue(result["valid"], result["errors"])
            self.assertIsNotNone(result["makespan"])

    def test_ineligible_machine_rejected(self):
        inst = generate_instance(2, 3, 2, "average", 9)
        schedule = solve(inst, 9)
        first = schedule[0]
        op = next(o for j in inst["jobs"] if j["job_id"] == first["job_id"]
                  for o in j["operations"] if o["operation_id"] == first["operation_id"])
        bad_machine = next(m for m in inst["machines"] if m not in op["eligible_machines"])
        first["machine_id"] = bad_machine
        result = validate_schedule(inst, schedule)
        self.assertFalse(result["valid"])
        self.assertTrue(any("Ineligible machine" in e for e in result["errors"]))

    def test_duplicate_and_missing_rejected(self):
        inst = generate_instance(2, 2, 2, "average", 4)
        schedule = solve(inst, 4)
        schedule.pop()
        schedule.append(copy.deepcopy(schedule[0]))
        result = validate_schedule(inst, schedule)
        self.assertFalse(result["valid"])
        self.assertTrue(any("Duplicate operation" in e for e in result["errors"]))
        self.assertTrue(any("Missing operation" in e for e in result["errors"]))

    def test_negative_start_rejected(self):
        inst = generate_instance(1, 2, 2, "average", 3)
        schedule = solve(inst, 3)
        schedule[0]["start_time"] = -1
        schedule[0]["completion_time"] = -1 + next(
            o["processing_times"][str(schedule[0]["machine_id"])]
            for o in inst["jobs"][0]["operations"]
            if o["operation_id"] == schedule[0]["operation_id"]
        )
        result = validate_schedule(inst, schedule)
        self.assertFalse(result["valid"])
        self.assertTrue(any("Negative start time" in e for e in result["errors"]))

    def test_overlap_rejected(self):
        inst = {
            "metadata": {},
            "machines": [1],
            "jobs": [
                {"job_id": 1, "operations": [
                    {"job_id": 1, "operation_id": 1, "eligible_machines": [1],
                     "processing_times": {"1": 5}}
                ]},
                {"job_id": 2, "operations": [
                    {"job_id": 2, "operation_id": 1, "eligible_machines": [1],
                     "processing_times": {"1": 5}}
                ]}
            ]
        }
        schedule = [
            {"job_id": 1, "operation_id": 1, "machine_id": 1, "start_time": 0, "completion_time": 5},
            {"job_id": 2, "operation_id": 1, "machine_id": 1, "start_time": 3, "completion_time": 8},
        ]
        result = validate_schedule(inst, schedule)
        self.assertFalse(result["valid"])
        self.assertTrue(any("overlapping" in e for e in result["errors"]))


if __name__ == "__main__":
    unittest.main()
